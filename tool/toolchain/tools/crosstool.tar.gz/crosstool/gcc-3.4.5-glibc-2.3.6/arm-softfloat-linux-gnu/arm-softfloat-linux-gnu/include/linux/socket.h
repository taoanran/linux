#if defined(__GNUC__) && !defined(__STRICT_ANSI__)
#warning "You should include <sys/socket.h>. This time I will do it for you."
#endif
#include <sys/socket.h>

